package nl.han.oose.lindt.maarten.services.exceptions;

public class NotConsistantDataException extends RuntimeException {
}
