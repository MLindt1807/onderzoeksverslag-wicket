package nl.han.oose.lindt.maarten.datasource.dao;

public class FailedResultsetReadingException extends RuntimeException {
}
