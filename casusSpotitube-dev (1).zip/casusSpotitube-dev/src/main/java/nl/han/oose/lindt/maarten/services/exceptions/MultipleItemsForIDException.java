package nl.han.oose.lindt.maarten.services.exceptions;

public class MultipleItemsForIDException extends RuntimeException {
}
