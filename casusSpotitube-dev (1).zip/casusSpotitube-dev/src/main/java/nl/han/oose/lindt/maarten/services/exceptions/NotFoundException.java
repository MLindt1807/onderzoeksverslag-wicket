package nl.han.oose.lindt.maarten.services.exceptions;

public class NotFoundException extends RuntimeException {
}
