package nl.han.oose.lindt.maarten.datasource.dao;

public class FailedConnectionException extends RuntimeException {
}

