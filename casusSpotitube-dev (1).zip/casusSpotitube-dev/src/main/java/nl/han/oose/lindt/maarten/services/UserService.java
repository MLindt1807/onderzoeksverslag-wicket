//package nl.han.oose.lindt.maarten.services;
//
//import nl.han.oose.lindt.maarten.services.dto.UserDTO;
//import nl.han.oose.lindt.maarten.services.dto.UserVerbindingDTO;
//import nl.han.oose.lindt.maarten.services.exceptions.VerbindingNotFoundException;
//
//import javax.xml.registry.infomodel.User;
//import java.util.ArrayList;
//import java.util.List;
//
//public class UserService {
//    private List<UserDTO> items = new ArrayList<UserDTO>();
//    private List<UserVerbindingDTO> verbindingen = new ArrayList<UserVerbindingDTO>();
//
////    public UserService() {
////        items.add(new UserDTO("jan","janWachtwoord"));
////        items.add(new UserDTO("jans","jansWachtwoord"));
////        items.add(new UserDTO("kinderen","kinderenWachtwoord"));
////    }
////
////
////
////    public UserVerbindingDTO getVerbinding(String user){
////        for(UserVerbindingDTO verbinding: verbindingen){
////            if(verbinding.getUser() == user){
////                return verbinding;
////            }else{
////                throw new VerbindingNotFoundException();
////            }
////        }
////    }
//
//
//}
