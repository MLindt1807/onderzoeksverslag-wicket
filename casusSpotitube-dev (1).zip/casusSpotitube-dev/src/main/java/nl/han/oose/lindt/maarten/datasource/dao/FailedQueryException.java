package nl.han.oose.lindt.maarten.datasource.dao;

public class FailedQueryException extends RuntimeException
{
}
